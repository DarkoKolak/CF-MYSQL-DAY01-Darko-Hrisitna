-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 03, 2019 at 03:23 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auctionhouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `bid`
--

CREATE TABLE `bid` (
  `bitid` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `biddate` date DEFAULT NULL,
  `bidhour` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fk_setid` int(11) DEFAULT NULL,
  `fk_username` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bid`
--

INSERT INTO `bid` (`bitid`, `amount`, `biddate`, `bidhour`, `fk_setid`, `fk_username`) VALUES
(1, 123, NULL, '2019-09-03 13:18:19', 1, 'user1');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `username` varchar(100) NOT NULL,
  `name` text DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`username`, `name`, `pass`, `email`) VALUES
('user1', 'First User', 'userone', 'user.one@gmail.com'),
('user2', 'Second User', 'usertwo', 'user.two@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(11) NOT NULL,
  `productname` varchar(100) DEFAULT NULL,
  `productdescription` varchar(500) DEFAULT NULL,
  `productphoto` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `productname`, `productdescription`, `productphoto`) VALUES
(11, 'Something1', 'This is something1', NULL),
(12, 'something2', 'This is something2', NULL),
(13, 'something3', 'This is something3', NULL),
(14, 'something4', 'This is something4', NULL),
(15, 'something5', 'This is something5', NULL),
(16, 'something6', 'This is something6', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setofproducts`
--

CREATE TABLE `setofproducts` (
  `setid` int(11) NOT NULL,
  `cataloguenumber` int(11) DEFAULT NULL,
  `startprice` int(11) DEFAULT NULL,
  `highestbid` int(11) DEFAULT NULL,
  `remainingtime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fk_productID1` int(11) DEFAULT NULL,
  `fk_productID2` int(11) DEFAULT NULL,
  `fk_productID3` int(11) DEFAULT NULL,
  `fk_productID4` int(11) DEFAULT NULL,
  `fk_productID5` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setofproducts`
--

INSERT INTO `setofproducts` (`setid`, `cataloguenumber`, `startprice`, `highestbid`, `remainingtime`, `fk_productID1`, `fk_productID2`, `fk_productID3`, `fk_productID4`, `fk_productID5`) VALUES
(1, 1, 123, NULL, '2019-09-03 13:16:22', 11, 12, 13, NULL, NULL),
(2, 2, 345, NULL, '2019-09-03 13:16:58', 14, 15, 16, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bid`
--
ALTER TABLE `bid`
  ADD PRIMARY KEY (`bitid`),
  ADD KEY `fk_setid` (`fk_setid`),
  ADD KEY `fk_username` (`fk_username`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `setofproducts`
--
ALTER TABLE `setofproducts`
  ADD PRIMARY KEY (`setid`),
  ADD KEY `setofproducts_ibfk_1` (`fk_productID1`),
  ADD KEY `fk_productID2` (`fk_productID2`),
  ADD KEY `fk_productID3` (`fk_productID3`),
  ADD KEY `fk_productID4` (`fk_productID4`),
  ADD KEY `fk_productID5` (`fk_productID5`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bid`
--
ALTER TABLE `bid`
  ADD CONSTRAINT `bid_ibfk_1` FOREIGN KEY (`fk_setid`) REFERENCES `setofproducts` (`setid`),
  ADD CONSTRAINT `bid_ibfk_2` FOREIGN KEY (`fk_username`) REFERENCES `customer` (`username`);

--
-- Constraints for table `setofproducts`
--
ALTER TABLE `setofproducts`
  ADD CONSTRAINT `setofproducts_ibfk_1` FOREIGN KEY (`fk_productID1`) REFERENCES `product` (`productid`),
  ADD CONSTRAINT `setofproducts_ibfk_2` FOREIGN KEY (`fk_productID2`) REFERENCES `product` (`productid`),
  ADD CONSTRAINT `setofproducts_ibfk_3` FOREIGN KEY (`fk_productID3`) REFERENCES `product` (`productid`),
  ADD CONSTRAINT `setofproducts_ibfk_4` FOREIGN KEY (`fk_productID4`) REFERENCES `product` (`productid`),
  ADD CONSTRAINT `setofproducts_ibfk_5` FOREIGN KEY (`fk_productID5`) REFERENCES `product` (`productid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
